
import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';

export default function App() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi] = useState('');
  const [classification, setClassification] = useState('');

  const calculateBMI = () => {
    const weightKg = parseFloat(weight);
    const heightCm = parseFloat(height);

    const heightM = heightCm / 100;
    const bmiResult = weightKg / (heightM * heightM);
    setBmi(bmiResult.toFixed(1));

 if (bmiResult < 18,5) 
        setClassification('Gầy');
        if (bmiResult >= 18.5 && bmiResult <= 24.9) 
        setClassification('Bình thường');
         if (bmiResult >= 25 && bmiResult <= 29.9) 
        setClassification('Tiền béo phì');
         if (bmiResult >= 30 && bmiResult <= 34.9) 
        setClassification('Béo phì cấp độ I');
         if (bmiResult >= 35 && bmiResult <= 39.9) 
        setClassification('Béo phì cấp độ II');
      else 
        setClassification('Béo phì cấp độ III');
  };

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text 
       style={{ fontSize: 20, color: '#3399FF', marginBottom: 10 }}
       >Chào mừng đến với</Text>
      <Text
       style={{ fontSize: 25, color: '#3399FF', marginBottom: 10 }}>Bảng Tính Chỉ Số BMI</Text>
      

      <Text>Nhập chiều cao (cm)</Text>
      <TextInput
        style={{ height: 40, width: 200, borderColor: '#3399FF', borderWidth: 1, marginBottom: 10 }}
        onChangeText={value => setHeight(value)}
        value={height}
        keyboardType="numeric"
      />


<Text>Nhập cân nặng (kg)</Text>
      <TextInput
        style={{ height: 40, width: 200, borderColor: '#3399FF', borderWidth: 1, marginBottom: 10 }}
        onChangeText={value => setWeight(value)}
        value={weight}
        keyboardType="numeric"
      />

      
      <Button title="Kiểm tra" onPress={calculateBMI} />

      {bmi !== '' && (
        <View>
          <Text>Kết quả chỉ số BMI: {bmi}</Text>
          <Text>Phân loại: {classification}</Text>
        </View>
      )}
    </View>
  );
}

